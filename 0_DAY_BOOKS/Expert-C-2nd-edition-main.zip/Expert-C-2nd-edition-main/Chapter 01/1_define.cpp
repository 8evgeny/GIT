#define NUMBER 41

int main() { 
    int a = NUMBER + 1; 
    return 0;  
}