#ifndef SQUARE_H
#define SQUARE_H

#include "rect.h"

struct Square : Rect 
{
    Square(double s) : Rect(0.0, 0.0) {}
};

#endif // SQUARE_H