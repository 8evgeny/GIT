#include <unordered_map>
#include <string>

int main()
{
  std::unordered_map<std::string, std::string> hashtable;
  hashtable["key1"] = "value 1";
  hashtable["key2"] = "value 2";
}