class Product {
public:
  Product() = default;
  // ...
};
