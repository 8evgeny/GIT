struct spaceship {
  bool is_military;
  int speed;
  int seats;
};
