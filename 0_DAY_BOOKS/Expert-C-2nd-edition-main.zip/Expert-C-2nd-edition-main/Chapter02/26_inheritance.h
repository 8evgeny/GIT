class Vehicle {
public:
  void move();
};

class Car : public Vehicle {
public:
  Car();
  // ...
};
