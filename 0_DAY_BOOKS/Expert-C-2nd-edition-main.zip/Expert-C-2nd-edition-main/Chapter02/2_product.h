struct Product {
  std::string name;
  double price;
  int rating;
  bool available;
};
