#include <string>
struct Product {
  std::string name;
  double price;
  int rating;
  bool available;
};

int main()
{
  Product book1;
  book1.rating = 4;
  book1.name = "Book";
  Product book2;
  book2.rating = 4;
  book2.name = "Book";
}
