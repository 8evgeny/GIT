#include <iostream>
struct Empty {};

int main() {
  Empty e;
  std::cout << sizeof(e);
}
