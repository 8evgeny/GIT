atomic_bool
atomic_char
atomic_schar
atomic_uchar
atomic_int
atomic_uint
atomic_short
atomic_ushort
atomic_long
atomic_ulong
atomic_llong
atomic_ullong
atomic_char16_t
atomic_char32_t
atomic_wchar_t


std::atomic<bool>
std::atomic<char>
std::atomic<signed char>
std::atomic<unsigned char>
std::atomic<int>
std::atomic<unsigned>
std::atomic<short>
std::atomic<unsigned short>
std::atomic<long>
std::atomic<unsigned long>
std::atomic<long long>
std::atomic<unsigned long long>
std::atomic<char16_t>
std::atomic<char32_t>
std::atomic<wchar_t>
