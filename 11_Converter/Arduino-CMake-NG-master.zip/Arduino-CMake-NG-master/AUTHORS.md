# Authors

This files lists all the authors of this project that helped it grow by adding code, fixing bugs, etc.

- [Tomasz Bogdal](https://github.com/queezythegreat) - Original author of **Arduino-CMake**
- [Timor Gruber](https://github.com/MrPointer) - Author of **Arduino-CMake-NG**, Current Maintainer
- [Tao Yuan](https://github.com/taoyuan)
- [Mike Machado](https://github.com/machadolab)
- [ooxi](https://github.com/ooxi)
- [tellowkrinkle](https://github.com/tellowkrinkle) - For archlinux & Fedora support

There are many other authors who have contributed to the various forks and versions, work which couldn't be done without them.

To all of you - Thank you very much!
