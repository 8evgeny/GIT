#include "include/GFXTest.h"

static Adafruit_GFX_Button gfxButton;

void testGFX()
{
    gfxButton.isPressed();
}
