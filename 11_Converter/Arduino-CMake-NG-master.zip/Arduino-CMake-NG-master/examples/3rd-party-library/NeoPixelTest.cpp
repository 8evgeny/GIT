#include "include/NeoPixelTest.hpp"

Adafruit_NeoPixel neoPixel;

void testNeoPixel()
{
    neoPixel.clear();
}
