#ifndef EXAMPLES_GFXTEST_HPP
#define EXAMPLES_GFXTEST_HPP

#include <Adafruit_GFX.h>

void testGFX();

#endif //EXAMPLES_GFXTEST_HPP
