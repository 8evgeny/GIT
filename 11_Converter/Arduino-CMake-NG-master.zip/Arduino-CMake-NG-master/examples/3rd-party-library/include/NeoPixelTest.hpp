#ifndef EXAMPLES_NEOPIXELTEST_HPP
#define EXAMPLES_NEOPIXELTEST_HPP

#include <Adafruit_NeoPixel.h>

void testNeoPixel();

#endif //EXAMPLES_NEOPIXELTEST_HPP
