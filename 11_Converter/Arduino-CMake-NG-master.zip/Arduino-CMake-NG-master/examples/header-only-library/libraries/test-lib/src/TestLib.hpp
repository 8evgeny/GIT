#ifndef EXAMPLES_TESTLIB_HPP
#define EXAMPLES_TESTLIB_HPP

#include <Arduino.h>

#define BAR 1
#define SOME_DELAY 200

void foo();

#endif //EXAMPLES_TESTLIB_HPP
