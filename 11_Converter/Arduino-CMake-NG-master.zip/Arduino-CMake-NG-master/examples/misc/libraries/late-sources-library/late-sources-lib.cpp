#include <Arduino.h>
#include <Adafruit_NeoPixel.h>

Adafruit_NeoPixel neoPixel;

void setup()
{
    neoPixel.clear();
}

void loop()
{
    
}
