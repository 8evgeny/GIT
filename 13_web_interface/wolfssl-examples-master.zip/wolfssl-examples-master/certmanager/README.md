# wolfSSL CertManager Example

This directory contains:

A simple example of using the wolfSSL CertManager to verify a certificate
in a standalone manner, separate from an SSL/TLS connection.

## Compiling and Running the Example

```
$ ./configure --enable-opensslextra
$ make
$ ./certverify
```
