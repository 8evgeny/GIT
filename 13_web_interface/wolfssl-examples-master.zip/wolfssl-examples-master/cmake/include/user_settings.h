#ifndef _USER_SETTINGS_INCLUDE
#define _USER_SETTINGS_INCLUDE

#define ECC_TIMING_RESISTANT
#define WC_RSA_BLINDING

//add your target specific defines here

#endif
