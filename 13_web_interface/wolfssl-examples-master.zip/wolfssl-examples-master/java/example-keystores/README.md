These are created from the example client/server certificates. These certificates are only for example purposes and are self-signed

Creating the keystores can be done by using the script update-jks.sh located at wolfssljni/examples/provider from the wolfssljni repository.

An example of calling the script would be ~/Documents/wolfssljni/examples/provider/update-jks.sh ~/Documents/wolfssl/certs

