# Curve25519 Example with Test Vectors

```sh
make
./curve25519_test
Secret Generated Alice: 4a5d9d5ba4ce2de1728e3bf480350f25e07e21c947d19e3376f09b3c1e161742
Secret Generated Bob: 4a5d9d5ba4ce2de1728e3bf480350f25e07e21c947d19e3376f09b3c1e161742
Secret Expected: 4a5d9d5ba4ce2de1728e3bf480350f25e07e21c947d19e3376f09b3c1e161742
Curve25519 test success
```
