/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A32
 */

#ifndef xconfig_benchmarkTest__
#define xconfig_benchmarkTest__



#endif /* xconfig_benchmarkTest__ */ 
