Example Summary
----------------
This application demonstrates the wolfssl/wolfcrypt/benchmark/benchmark.c

optimization flags used
----------------

--abi=eabi -me -03
--opt_for_speed=5
--optimizer_interlist
--remove_hooks_when_inlining
--opt_for_cache
--gen_opt_info=2
--call_assumptions=3
--auto_inline=5
--single_inline
--aliased_variables
