#!/bin/bash

export PATH=$PATH:/opt/gcc-arm-none-eabi-6-2017-q2-update/bin
export PATH=$PATH:/opt/gnu-mcu-eclipse/openocd/0.10.0-4-20171004-0812-dev/bin
