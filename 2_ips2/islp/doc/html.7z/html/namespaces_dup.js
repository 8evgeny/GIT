var namespaces_dup =
[
    [ "ISLP", "d9/dc9/namespace_i_s_l_p.html", null ]
];