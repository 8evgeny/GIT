/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "ISLP", "index.html", [
    [ "ISLP", "index.html#autotoc_md0", [
      [ "Contents:", "index.html#autotoc_md2", null ]
    ] ],
    [ "Part 1. Protocol description.", "d1/d1b/protocol.html", [
      [ "1. Common description", "d1/d1b/protocol.html#common", null ],
      [ "2. Stations description", "d1/d1b/protocol.html#stations", null ],
      [ "3. Functions description", "d1/d1b/protocol.html#functions", [
        [ "3.1 Yell(Key)", "d1/d1b/protocol.html#fn_yell", null ],
        [ "3.2 StationInfo(Station)", "d1/d1b/protocol.html#fn_response", null ],
        [ "3.3 SetIP(Station)", "d1/d1b/protocol.html#fn_setip", null ],
        [ "3.4 Accept(Station)", "d1/d1b/protocol.html#fn_accept", null ]
      ] ]
    ] ],
    [ "Part 2. RelationsModel.", "d9/dfa/relations.html", null ],
    [ "Part 3. Realisation example.", "dc/db5/realisation.html", null ],
    [ "ISLP", "d3/dcc/md__r_e_a_d_m_e.html", [
      [ "Структура пакетов:", "d3/dcc/md__r_e_a_d_m_e.html#autotoc_md4", null ],
      [ "Взаимодействие", "d3/dcc/md__r_e_a_d_m_e.html#autotoc_md5", null ],
      [ "Структура intercomStation", "d3/dcc/md__r_e_a_d_m_e.html#autotoc_md6", null ],
      [ "Описание функций", "d3/dcc/md__r_e_a_d_m_e.html#autotoc_md7", [
        [ "Yell", "d3/dcc/md__r_e_a_d_m_e.html#autotoc_md8", null ],
        [ "StationInfo", "d3/dcc/md__r_e_a_d_m_e.html#autotoc_md9", null ],
        [ "SetIP", "d3/dcc/md__r_e_a_d_m_e.html#autotoc_md10", null ],
        [ "Accept", "d3/dcc/md__r_e_a_d_m_e.html#autotoc_md11", null ]
      ] ],
      [ "Маскировка полей, сессионный ключ.", "d3/dcc/md__r_e_a_d_m_e.html#autotoc_md12", null ],
      [ "ID типов станций", "d3/dcc/md__r_e_a_d_m_e.html#autotoc_md13", null ]
    ] ],
    [ "Todo List", "dd/da0/todo.html", null ],
    [ "Namespaces", "namespaces.html", [
      [ "Namespace List", "namespaces.html", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.html", [
      [ "Data Structures", "annotated.html", "annotated_dup" ],
      [ "Data Structure Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Data Fields", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';