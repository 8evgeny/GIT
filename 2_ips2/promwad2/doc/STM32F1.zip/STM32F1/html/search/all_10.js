var searchData=
[
  ['queue',['queue',['../class_g_p_i_o.html#a38958eadef2f11215dd7e6da598f41ea',1,'GPIO']]],
  ['queue_5fsz',['queue_sz',['../structos__message_q__def.html#afc8e51d4d45e959fab77977baf8eb970',1,'os_messageQ_def::queue_sz()'],['../structos__mail_q__def.html#a2614df3d7904500621666abc01808f22',1,'os_mailQ_def::queue_sz()']]]
];
