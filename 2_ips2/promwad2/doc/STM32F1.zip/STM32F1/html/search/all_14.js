var searchData=
[
  ['ultasknotifytake',['ulTaskNotifyTake',['../group__ul_task_notify_take.html',1,'']]],
  ['unshift',['unshift',['../class_circular_buffer.html#ab4c0d58c8de144b26c438cc2e6f29e4b',1,'CircularBuffer']]],
  ['usagefault_5fhandler',['UsageFault_Handler',['../stm32f1xx__it_8h.html#a1d98923de2ed6b7309b66f9ba2971647',1,'UsageFault_Handler(void):&#160;stm32f1xx_it.c'],['../stm32f1xx__it_8c.html#a1d98923de2ed6b7309b66f9ba2971647',1,'UsageFault_Handler(void):&#160;stm32f1xx_it.c']]],
  ['uxqueuemessageswaiting',['uxQueueMessagesWaiting',['../group__ux_queue_messages_waiting.html',1,'']]],
  ['uxtaskgetnumberoftasks',['uxTaskGetNumberOfTasks',['../group__ux_task_get_number_of_tasks.html',1,'']]],
  ['uxtaskpriorityget',['uxTaskPriorityGet',['../group__ux_task_priority_get.html',1,'']]]
];
