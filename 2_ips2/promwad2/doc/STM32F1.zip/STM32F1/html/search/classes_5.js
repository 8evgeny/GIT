var searchData=
[
  ['heapregion',['HeapRegion',['../struct_heap_region.html',1,'']]]
];
