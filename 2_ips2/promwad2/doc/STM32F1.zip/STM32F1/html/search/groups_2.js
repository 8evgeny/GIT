var searchData=
[
  ['pctaskgethandle',['pcTaskGetHandle',['../group__pc_task_get_handle.html',1,'']]],
  ['pctaskgetname',['pcTaskGetName',['../group__pc_task_get_name.html',1,'']]]
];
