var searchData=
[
  ['ultasknotifytake',['ulTaskNotifyTake',['../group__ul_task_notify_take.html',1,'']]],
  ['uxqueuemessageswaiting',['uxQueueMessagesWaiting',['../group__ux_queue_messages_waiting.html',1,'']]],
  ['uxtaskgetnumberoftasks',['uxTaskGetNumberOfTasks',['../group__ux_task_get_number_of_tasks.html',1,'']]],
  ['uxtaskpriorityget',['uxTaskPriorityGet',['../group__ux_task_priority_get.html',1,'']]]
];
