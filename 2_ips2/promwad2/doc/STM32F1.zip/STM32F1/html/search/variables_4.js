var searchData=
[
  ['def',['def',['../structos_event.html#ae35ea802f7b6476aa21e72f038adc1a3',1,'osEvent']]],
  ['dummy',['dummy',['../structos__mutex__def.html#a6364fe3b28142d23aaa03343c627957f',1,'os_mutex_def::dummy()'],['../structos__semaphore__def.html#aa95cbcddf4e435fc610035765a58269d',1,'os_semaphore_def::dummy()']]]
];
