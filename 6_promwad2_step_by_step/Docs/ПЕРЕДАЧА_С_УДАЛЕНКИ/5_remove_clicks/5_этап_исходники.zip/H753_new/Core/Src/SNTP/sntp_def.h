#ifndef SNTP_DEF_H
#define SNTP_DEF_H

#endif // SNTP_DEF_H
