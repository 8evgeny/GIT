#ifndef CONSTANTS_H
#define CONSTANTS_H



namespace constants
{
//  inline constexpr uint8_t isrVectorTableSize = 67;
//  inline constexpr int isrVectorTableAlingment = 0x100;
  constexpr uint8_t isrVectorTableSize = 91;
  constexpr int isrVectorTableAlingment = 0x100;
}



#endif // CONSTANTS_H
