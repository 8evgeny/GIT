# emdr1986x-std-per-lib
<b>Milandr MCU 1986x Standard Peripherals Library</b>

This isn't official library that compatible with GCC compiler.

<b>Now next MCU support gcc compiler:</b>
- MDR1986VE9x
- MDR1986VE1T
- MDR1986VE3 (not tested)
- MDR1986BE4 (not tested)

<b>Documentation:</b>

https://github.com/eldarkg/emdr1986x-std-per-lib-doc
